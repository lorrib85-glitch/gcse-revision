Medicine causes card images

Use the 1024px .webp files as the primary app assets.
Use the 512px .webp files for thumbnails/preload/low-data states.
JPEG files are included as broad fallback only.

Suggested app paths:
/assets/history/medicine/causes/god_sin-1024.webp
/assets/history/medicine/causes/four_humours_treatment-1024.webp
/assets/history/medicine/causes/miasma-1024.webp
/assets/history/medicine/causes/astrology-1024.webp
